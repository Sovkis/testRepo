package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import framework.webPages.DarkSkyLogIn;
import framework.webPages.HomePage;
import org.testng.Assert;

public class DarkSkySD {

    private HomePage homePage = new HomePage();
    private DarkSkyLogIn loginPage = new DarkSkyLogIn();
    private DarkSkyLogIn HomePage = new DarkSkyLogIn();

    @Given("^I am on the darksky Register page$")
    public void iAmOnRegisterPage(){
        homePage.clickOnApi();
        homePage.clickOnLogin();
    }
    @When("^When i click on Register button$")
    public void registerVerify(){
        loginPage.clickOnLogInToDarkSky();
    }

    @Then("^I verify error message'please fill out this field'$")
    public void errorMessage(){
        Assert.assertEquals("https://darksky.net/dev/login",SharedSD.getDriver());

    }

    @Given("^I am on Darksky Home Page$")
    public void OnHomePage(){
        SharedSD.getDriver().manage().window().maximize();
    }

    @Then("^I verify current temperature is not greater or less then temps from daily timeline$")
    public void WeatherChecking(){
        HomePage.checkTheWeather();

    }

    @When("^I expand todays timeline$")
    public void Timeline(){
        HomePage.clickOnTodayExpandButton();
    }

    @Then("^I verify lowest and highest temp is displayed correctly$")
    public void WeatherComparison(){
        HomePage.TodaysWeather();
    }


    @Then("^I verify timeline is displayed with two hours incremented$")
    public void TimeIncrementation(){
        HomePage.timeIncrement();
    }
}

