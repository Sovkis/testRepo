package stepdefinition;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import framework.webPages.HotelsDotComLandingPage;
import framework.webPages.HotelsHomePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

public class HotelSD {

        HotelsHomePage hdchp = new HotelsHomePage();
        HotelsDotComLandingPage landPages = new HotelsDotComLandingPage();

        @Given("^I am on default locations search result screen$")
        public void verifySearchResultScreen(){

            SharedSD.getDriver().manage().window().maximize();

                landPages.setCity();
                landPages.DropDown();
                landPages.searchButton();}

        @When("^I select property class (.+) stars$")
        public void propertySelection(String star){
            String  beginning ="//input[@id='f-star-rating-";
            String end ="']";
            JavascriptExecutor js = (JavascriptExecutor) SharedSD.getDriver();
            js.executeScript("arguments[0].scrollIntoView(true);", SharedSD.getDriver().findElement(By.xpath(beginning + star + end)));
            SharedSD.getDriver().findElement(By.xpath(beginning + star + end)).click();
        }

        @Then("^I verify system displays only (.+) stars hotels on search result$")
        public void displayOnlyProperStarClass(int numberOfStars) throws InterruptedException {
            hdchp.scroll();
            hdchp.showStarsForHotels(numberOfStars);
            }

        @Then("^I verify system displays all hotels within 10 miles radius of airport$")
        public void displayHotelMileage() throws InterruptedException{
            hdchp.clickOnDistanceButton();
            Thread.sleep(8000);
            hdchp.pullOutDataAboutDistanceFromHotel();
        }

        @And("^I verify Hilton Hotel is within radius$")
        public void showHiltonHotel(){
            hdchp.verifyHotelNameIsDisplayed("hilton");
        }
    }


