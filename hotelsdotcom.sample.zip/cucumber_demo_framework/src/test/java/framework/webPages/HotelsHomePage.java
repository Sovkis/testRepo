package framework.webPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import stepdefinition.SharedSD;

import java.util.ArrayList;
import java.util.List;
public class HotelsHomePage extends BasePage {

    private By starsRating = By.xpath("//span[@class='star-rating-text']");
    private By hotelsNames = By.xpath("//a[@class='property-name-link']");
    private By locationButton = By.xpath("//a[contains(text(),'Distance')]");
    private By airport = By.xpath("//li[@class='section-airports root-section']//ul//li//a[contains(text(),'Los Angeles Intl. (LAX)')]");
    private By distanceToTheHotel = By.xpath("//ul[@class='property-landmarks']/li[1]");



    public void scroll() throws InterruptedException {
        for (int i = 0; i < 10; i++) {
            JavascriptExecutor js = (JavascriptExecutor) SharedSD.getDriver();
            js.executeScript("window.scrollBy(0,1000)");
            Thread.sleep(3000);
            i++;
        }
    }

    public void showStarsForHotels(int stars) {
        List<WebElement> hotelStars = SharedSD.getDriver().findElements(starsRating);
        boolean isStarsCorrect = true;
        List<Integer> numberOfStars = new ArrayList<>();
        for (WebElement st : hotelStars) {
            String[] number = st.getText().split("[.]|-");
            String ind = number[0];
            int fin = Integer.parseInt(ind);
            numberOfStars.add(fin);
            if ((fin >= stars + 1) || (fin < stars)) {
                isStarsCorrect = false;
                if (numberOfStars.size() == 50) {
                    break;
                }
            }
        }
        Assert.assertTrue(isStarsCorrect);
    }

    public void clickOnDistanceButton() throws InterruptedException {
        mouseOver(locationButton);
        Thread.sleep(2000);
        SharedSD.getDriver().findElement(airport).click();
        Thread.sleep(2000);
    }

    public void pullOutDataAboutDistanceFromHotel() {

        try {
            boolean distanceIsLessThan10 = false;
            List<WebElement> distanceList = SharedSD.getDriver().findElements(distanceToTheHotel);
            List<String> webToArray = new ArrayList<>();
            int i = 0;
            for (WebElement distanceListCompare : distanceList) {
                webToArray.add(distanceListCompare.getText().replaceAll("\\D", ""));
                int num = Integer.valueOf(String.valueOf(webToArray));
                if (num <= 10) {
                    num++;
                    distanceIsLessThan10 = true;
                }
                Assert.assertTrue(distanceIsLessThan10, "This distance is less than or equal to 10");
            }
        } catch (NumberFormatException nfe) {
            System.out.println("Number Problem caught");
        }
    }

    public void verifyHotelNameIsDisplayed(String hotelName) {
        List<WebElement> distanceList = SharedSD.getDriver().findElements(hotelsNames);
        boolean isHiltonDisplayed = false;
        for (WebElement hotel : distanceList) {
            if (hotel.getText().toLowerCase().contains(hotelName)) {
                isHiltonDisplayed = true;
            }
            Assert.assertTrue(isHiltonDisplayed, hotelName + " is out of range");
        }
    }
}