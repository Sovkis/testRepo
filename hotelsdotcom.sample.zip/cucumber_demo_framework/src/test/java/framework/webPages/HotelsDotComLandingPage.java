package framework.webPages;

import org.openqa.selenium.By;

public class HotelsDotComLandingPage extends BasePage {
    HomePage hp = new HomePage();

    private By PopUp = By.xpath("//button[@class='cta widget-overlay-close']");
    private By searchButton = By.xpath("//button[@class='cta cta-strong']");
    private By city = By.xpath("//input[@id='qf-0q-destination']");
    private By dropDown = By.xpath("//h1[@class='cont-hd-alt widget-query-heading']");


    public void PopUp(){hp.clickOn(PopUp);}

    public void searchButton(){hp.clickOn(searchButton);}

    public void setCity(){hp.setValue(city, "Los Angeles");}

    public void DropDown(){hp.clickOn(dropDown);}
}
